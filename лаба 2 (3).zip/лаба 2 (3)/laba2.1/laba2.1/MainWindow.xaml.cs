﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace laba2._1
{

    public partial class MainWindow : Window
    {
        private readonly Dictionary<string, Color> colorMap = new Dictionary<string, Color>
        {
            { "Красный", Colors.Red },
            { "Red", Colors.Red },
            { "Оранжевый", Colors.Orange },
            { "Orange", Colors.Orange },
            { "Желтый", Colors.Yellow },
            { "Yellow", Colors.Yellow },
            { "Зеленый", Colors.Green },
            { "Green", Colors.Green }
        };
        private readonly Dictionary<string, string> colorNamesRu = new Dictionary<string, string>
        {
            { "Red", "Красный" },
            { "Orange", "Оранжевый" },
            { "Yellow", "Желтый" },
            { "Green", "Зеленый" },
            { "Красный", "Красный" },
            { "Оранжевый", "Оранжевый" },
            { "Желтый", "Желтый" },
            { "Зеленый", "Зеленый" }
        };
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ColorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                ChangeBackgroundColor(menuItem.Header.ToString());
            }
        }

        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string colorName)
            {
                ChangeBackgroundColor(colorName);
            }
        }

        private void ChangeBackgroundColor(string colorName)
        {
            if (colorMap.TryGetValue(colorName, out Color color))
            {
                this.Background = new SolidColorBrush(color);

                // Обновляем строку состояния с названием цвета
                if (colorNamesRu.TryGetValue(colorName, out string colorNameRu))
                {
                    StatusText.Text = $"Текущий цвет фона: {colorNameRu}";
                }
                else
                {
                    StatusText.Text = $"Текущий цвет фона: {colorName}";
                }
            }
            else
            {
                this.Background = new SolidColorBrush(Colors.White);
                StatusText.Text = "Текущий цвет фона: Белый";
            }
        }

        private void ResetColor_Click(object sender, RoutedEventArgs e)
        {
            this.Background = new SolidColorBrush(Colors.White);
            StatusText.Text = "Текущий цвет фона: Белый";
        }

        private void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Программа для изменения цвета фона разработана студенткой БРУ гр. АСОИ-221 Шпаковой Ксенией Олеговной.\nВыберите цвет из меню или панели инструментов.", "О программе");
        }

        private void CloseMenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}