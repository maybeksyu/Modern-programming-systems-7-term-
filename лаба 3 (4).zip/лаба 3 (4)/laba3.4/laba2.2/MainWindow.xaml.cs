﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Media;

namespace laba2._2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Установка начальных обработчиков
            colorComboBox.SelectionChanged += OnDrawingParametersChanged;
            brushSizeSlider.ValueChanged += OnDrawingParametersChanged;

            // Инициализация начальных значений
            UpdateDrawingAttributes();
        }

        private void OnDrawingParametersChanged(object sender, RoutedEventArgs e)
        {
            UpdateDrawingAttributes();
        }

        private void UpdateDrawingAttributes()
        {
            var drawingAttributes = new DrawingAttributes();

            // Установка цвета
            if (colorComboBox.SelectedItem is ComboBoxItem colorItem && colorItem.Background is SolidColorBrush brush)
            {
                drawingAttributes.Color = brush.Color;
            }
            else
            {
                drawingAttributes.Color = Colors.Black; // цвет по умолчанию
            }

            // Установка размера
            drawingAttributes.Width = brushSizeSlider.Value;
            drawingAttributes.Height = brushSizeSlider.Value;

            drawingCanvas.DefaultDrawingAttributes = drawingAttributes;
        }
    }
}