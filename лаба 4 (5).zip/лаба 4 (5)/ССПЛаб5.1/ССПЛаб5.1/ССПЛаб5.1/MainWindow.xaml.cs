﻿using System.Windows;
using System.Windows.Controls;

namespace MultiEdit
{
    public partial class MainWindow : Window
    {
        private TextBox currentLargeTextBox;

        public MainWindow()
        {
            InitializeComponent();
            // Изначально левое большое поле активно
            SetLargeTextBox(LeftLargeTextBox);
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null)
            {
                // Если это большое текстовое поле
                if (textBox.Name == "LeftLargeTextBox" || textBox.Name == "RightLargeTextBox")
                {
                    SetLargeTextBox(textBox);
                }
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            
        }

        private void SetLargeTextBox(TextBox largeTextBox)
        {
            // Сбрасываем все большие текстовые поля к маленькому стилю
            LeftLargeTextBox.Style = (Style)Resources["SmallTextBoxStyle"];
            RightLargeTextBox.Style = (Style)Resources["SmallTextBoxStyle"];

            // Устанавливаем выбранное поле как большое
            largeTextBox.Style = (Style)Resources["LargeTextBoxStyle"];
            currentLargeTextBox = largeTextBox;
        }
    }
}