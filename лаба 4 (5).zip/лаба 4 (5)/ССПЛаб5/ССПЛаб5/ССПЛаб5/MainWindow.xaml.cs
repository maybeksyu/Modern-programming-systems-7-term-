﻿using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WPFApp
{
    public partial class GraphicEditorWindow : Window
    {
        private DrawingAttributes currentDrawingAttributes;

        public GraphicEditorWindow()
        {
            InitializeComponent();

            // Инициализация атрибутов рисования
            currentDrawingAttributes = new DrawingAttributes
            {
                Color = Colors.Black,
                Width = 3,
                Height = 3,
            };

            // Установка атрибутов по умолчанию
            DrawingCanvas.DefaultDrawingAttributes = currentDrawingAttributes;
            DrawingCanvas.EditingMode = InkCanvasEditingMode.Ink;

            // Инициализация ComboBox
            InitializeColorComboBox();
        }

        private void InitializeColorComboBox()
        {
            // Убедимся, что выбран элемент по умолчанию
            if (ColorComboBox.Items.Count > 0)
            {
                ColorComboBox.SelectedIndex = 0;
            }
        }

        private void ColorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ColorComboBox.SelectedItem is ComboBoxItem item && item.Tag != null)
            {
                string colorName = item.Tag.ToString();
                try
                {
                    Color color = (Color)ColorConverter.ConvertFromString(colorName);
                    currentDrawingAttributes.Color = color;
                    DrawingCanvas.DefaultDrawingAttributes = currentDrawingAttributes;
                    EditorStatusText.Text = $"Цвет изменен на {item.Content}";
                }
                catch
                {
                    EditorStatusText.Text = "Ошибка выбора цвета";
                }
            }
        }

        private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (BrushSizeText != null)
            {
                double size = BrushSizeSlider.Value;
                BrushSizeText.Text = size.ToString("F0");

                if (currentDrawingAttributes != null)
                {
                    currentDrawingAttributes.Width = size;
                    currentDrawingAttributes.Height = size;
                    DrawingCanvas.DefaultDrawingAttributes = currentDrawingAttributes;
                }
            }
        }

        private void ModeRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton && EditorStatusText != null)
            {
                switch (radioButton.Content.ToString())
                {
                    case "Рисование":
                        DrawingCanvas.EditingMode = InkCanvasEditingMode.Ink;
                        EditorStatusText.Text = "Режим: Рисование";
                        break;
                    case "Редактирование":
                        DrawingCanvas.EditingMode = InkCanvasEditingMode.Select;
                        EditorStatusText.Text = "Режим: Редактирование";
                        break;
                    case "Удаление":
                        DrawingCanvas.EditingMode = InkCanvasEditingMode.EraseByPoint;
                        EditorStatusText.Text = "Режим: Удаление";
                        break;
                }
            }
        }


        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (CoordinatesText != null)
            {
                Point position = e.GetPosition(DrawingCanvas);
                CoordinatesText.Text = $"X: {(int)position.X}, Y: {(int)position.Y}";
            }
        }

        // Обработчик загрузки окна для дополнительной инициализации
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DrawRadioButton.IsChecked = true;
        }
    }
}