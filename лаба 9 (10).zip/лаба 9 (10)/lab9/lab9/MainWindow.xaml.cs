﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System;

namespace lab9
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Switch_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is FrameworkElement fe)
                ScaleAnimation(FindParentViewbox(fe), 1.2);
        }

        private void Switch_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is FrameworkElement fe)
                ScaleAnimation(FindParentViewbox(fe), 1.0);
        }

        private void Switch_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement fe)
            {
                // Ищем RotateTransform по имени: Switch{N}Rotate
                string groupName = fe.Name; // например, "Switch1Group"
                string rotName = groupName.Replace("Group", "Rotate"); // → "Switch1Rotate"
                var rot = FindName(rotName) as RotateTransform;
                if (rot != null)
                {
                    rot.BeginAnimation(
                        RotateTransform.AngleProperty,
                        new DoubleAnimation(rot.Angle + 20, TimeSpan.FromMilliseconds(300))
                        {
                            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
                        });
                }
            }
        }

        private Viewbox FindParentViewbox(DependencyObject obj)
        {
            while (obj != null && !(obj is Viewbox))
                obj = VisualTreeHelper.GetParent(obj);
            return obj as Viewbox;
        }

        private void ScaleAnimation(Viewbox viewbox, double scale)
        {
            if (viewbox == null) return;

            var st = viewbox.RenderTransform as ScaleTransform;
            if (st == null)
            {
                st = new ScaleTransform();
                viewbox.RenderTransform = st;
                viewbox.RenderTransformOrigin = new Point(0.5, 0.5);
            }

            var anim = new DoubleAnimation(scale, TimeSpan.FromMilliseconds(200))
            {
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            st.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            st.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }
    }
}