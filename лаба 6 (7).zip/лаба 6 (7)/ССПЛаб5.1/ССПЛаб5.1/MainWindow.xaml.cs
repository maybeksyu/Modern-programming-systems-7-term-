﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace MultiEdit
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Изначально левое большое
            AnimateExpand(LeftLargeTextBox);
            AnimateCollapse(RightLargeTextBox);
        }

        private void LargeTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox focused)
            {
                if (focused == LeftLargeTextBox)
                {
                    AnimateExpand(LeftLargeTextBox);
                    AnimateCollapse(RightLargeTextBox);
                }
                else if (focused == RightLargeTextBox)
                {
                    AnimateExpand(RightLargeTextBox);
                    AnimateCollapse(LeftLargeTextBox);
                }
            }
        }

        private void AnimateExpand(TextBox textBox)
        {
            var sb = (Storyboard)FindResource("ExpandStoryboard");
            Storyboard.SetTarget(sb, textBox);
            sb.Begin(this);
        }

        private void AnimateCollapse(TextBox textBox)
        {
            var sb = (Storyboard)FindResource("CollapseStoryboard");
            Storyboard.SetTarget(sb, textBox);
            sb.Begin(this);
        }
    }
}