﻿using System;
using System.Windows;
using System.Windows.Input;

namespace task2
{

    public partial class MainWindow : Window
    {
        private Random random = new Random();
        public MainWindow()
        {
            InitializeComponent();
         RunawayButton.MouseEnter += RunawayButton_MouseEnter;
            }

            private void RunawayButton_MouseEnter(object sender, MouseEventArgs e)
            {
                // Простое перемещение через Margin
                RunawayButton.Margin = new Thickness(
                    random.Next(0, (int)(ActualWidth - 120)),
                    random.Next(0, (int)(ActualHeight - 40)),
                    0, 0);
            }
        }
    }